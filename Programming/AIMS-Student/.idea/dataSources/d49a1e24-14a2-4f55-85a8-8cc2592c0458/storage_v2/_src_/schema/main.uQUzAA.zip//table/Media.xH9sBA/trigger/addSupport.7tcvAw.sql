CREATE TRIGGER addSupport  AFTER INSERT ON Media
    BEGIN

        INSERT OR REPLACE INTO Media  (supportRushOrder) values (true);
END;

